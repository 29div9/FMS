 
	 function search(){
 

	var filmId=searchForm.byId.value;
	alert(filmId);
	//Ajax Code 
	var xhr = new XMLHttpRequest();
	 if(filmId!="")
		 {
		 alert("hello");
		 }
}
	 