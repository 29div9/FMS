
      // Form validation code will come here.
function istitlevalidate()  
{   
		var filmtitle=myForm.title.value;
		//var flag=false;
		var regExp = ("^[a-zA-Z0-9\\-\\s]+$");  
		if(filmtitle.match(regExp))  
		{  
			document.getElementById("titleErr").innerHTML="";
			return true;  
		}  
		else  
		{ 
			document.getElementById("titleErr").innerHTML="*Title should only contain alphabet"; 
			//filmtitle.focus();  
			return false;  
		} 
		
			
}


function isdescriptionvalidate() {
	var description=myForm.description.value;
    if (description == null || description == "") {
    	document.getElementById("descriptionErr").innerHTML="*Description must be filled out"; 
        return false;
    }
    else
    	{
    	document.getElementById("descriptionErr").innerHTML="";
		return true;  
    	}
}

function isspecialvalidate()  
{  var regExp = ("^[a-zA-Z0-9\\-\\s]+$");
		
		if(myForm.special_feature.value.match(regExp))  
		{  
			document.getElementById("special_featureErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("special_featureErr").innerHTML="*Special Feature cannot be empty"; 
			 document.myForm.special_feature.focus();  
			return false;  
		}  
}
function isValidRental()
{
var release=myForm.release_date.value;
var rental=myForm.rental_duration.value;

if(rental<release)
	{
	document.getElementById("rentalErr").innerHTML="*Rental date cannot be greater than release year"; 
	 document.myForm.rental_duration.focus(); 
	 return false;
	}
else
	{
	document.getElementById("rentalErr").innerHTML=""; 
	return true;
	}
}
function isreplacementvalidate()  
{   var numbers = /^[0-9]+$/;
		
		if(myForm.replacement_cost.value.match(numbers))  
		{  
			document.getElementById("replacement_costErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("replacement_costErr").innerHTML="*replacement cost should be number"; 
			 document.myForm.replacement_cost.focus();  
			return false;  
		}  
}

function isValidLength()  
{  
   var numbers = /^[0-9]+$/;  
   if(myForm.length.value.match(numbers))  
   {  
	   document.getElementById("lengthErr").innerHTML="";
  
   return true;  
   }  
   else  
   {  
	   document.getElementById("lengthErr").innerHTML="*length should only contain numbers";   
	   document.myForm.length.focus();   
   return false;  
   }  
}

function searchfilm()
{
	
alert("hello");
		
}

function isNameValidate()  
{   
		var name=myForm.first_name.value;
		var letters =("^[a-zA-Z0-9\\-\\s]+$"); 
		if(name.match(letters))  
		{  
			document.getElementById("nameErr").innerHTML="";
			return true;  
		}  
		else  
		{ 
			document.getElementById("nameErr").innerHTML="*Name should only contain alphabet"; 
			  
			return false;
		} 
		
			
}


