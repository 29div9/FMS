package org.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;

public class IActorDAOImplementation implements IActorDao{
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMS","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("connected...");
		
		return connection;
	}

	@Override
	public List<Actor> getActors() {
		List<Actor> actors=new ArrayList<>();
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from ACTOR";
		
		
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			
            ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_id(rs.getInt(1));
				actor.setActor_firstName(rs.getString(2));
				actor.setActor_lastName(rs.getString(3));
				actors.add(actor);
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(languages);
		return actors;
		
	}

	@Override
	public void addActor(Actor actor) {
		Connection con=getConnection();
		String sql="INSERT INTO ACTOR(first_name,last_name) VALUES(?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1,actor.getActor_firstName());
			pst.setString(2,actor.getActor_lastName());
			int count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Actor> getAllActors() {
		List<Actor> actorList=new ArrayList<>();
		Connection con=getConnection();
		String sql;
		sql="select * from ACTOR";
		try {
			PreparedStatement pst;
			pst=con.prepareStatement(sql);
			ResultSet rs;
			rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_id(rs.getInt(1));;
				actor.setActor_firstName(rs.getString(2));
				actor.setActor_lastName(rs.getString(3));
			    actorList.add(actor);
			}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
return actorList;
}

	@Override
	public boolean deleteActor(int actorid) {
		System.out.println(actorid);
		Connection con=getConnection();
		boolean flag=false;
		String sql="DELETE ACTOR, FILM_ACTOR FROM ACTOR LEFT JOIN FILM_ACTOR ON ACTOR.actor_Id=FILM_ACTOR.actor_id WHERE ACTOR.actor_id=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, actorid);
			int count=pst.executeUpdate();
			if(count>0)
				flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(sql);
		return flag;
		
	}
}
