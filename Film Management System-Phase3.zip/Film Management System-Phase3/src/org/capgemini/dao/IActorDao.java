package org.capgemini.dao;

import java.util.List;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;

public interface IActorDao {
	public List<Actor> getActors();
	public void addActor(Actor actor);
	public List<Actor> getAllActors();
	public boolean deleteActor(int actorid);
}
