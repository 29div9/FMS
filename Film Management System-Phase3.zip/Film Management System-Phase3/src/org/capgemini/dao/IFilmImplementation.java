package org.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import java.sql.Date;
public class IFilmImplementation implements IFilmDao{
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMS","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("connected...");
		
		return connection;
	}

	private Map<Integer, Film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from LANGUAGES";
		
		
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			
            ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language language=new Language();
				language.setLanguage_id(rs.getInt(1));
				language.setLanguage_name(rs.getString(2));
				languages.add(language);
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from CATEGORY";
try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
			Category category1=new Category();
				category1.setCategory_id(rs.getInt(1));
				category1.setCategory_name(rs.getString(2));
				category.add(category1);
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(languages);
		return category;
	}

	//CURD Operation
		@Override
		public int addFilm(Film film) {
			int count=0;
			Connection con=getConnection();
			String sql="INSERT INTO FILM (title,description,releaseYear,originalLanguage,rentalDuration,len,replacementCost,ratings,specialFeatures,category) VALUES (?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2,film.getDescription());
				pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
				pst.setInt(4, film.getOriginalLanguage().getLanguage_id());
				pst.setDate(5, new java.sql.Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7, film.getReplacementCost());
				pst.setInt(8, film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				pst.setInt(10,film.getCategory().getCategory_id());
				 count=pst.executeUpdate();
				//if insertion to film table is success execute
				if(count>0){
					
					//insertion to third party tables
					int filmId=0;
					
					sql="select film_id from FILM ORDER BY film_id DESC LIMIT 1";
							
					PreparedStatement stmt = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery();
					
					while(rs.next()){
							
						filmId = rs.getInt(1);
					}
					
					
					sql="insert into FILM_ACTOR(film_id,actor_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the actors in the film
					Set<Actor> actors = film.getActors();			
					for(Actor act: actors){
						pst.setInt(1, filmId );
						pst.setInt(2, act.getActor_id() );
						
						count=pst.executeUpdate();
					}
					
									
					sql="insert into FILM_LANGUAGE(film_id,language_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the other languages
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, filmId );
						pst.setInt(2, lang.getLanguage_id());
						
						count=pst.executeUpdate();
					}
					
				}
			con.close();
			}
				catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return count;
		}

		
		@Override
		public boolean deleteFilm(int filmid) {
			Connection con=getConnection();
			boolean flag=false;
					String sql="DELETE FILM,FILM_ACTOR,FILM_LANGUAGE FROM FILM LEFT JOIN FILM_ACTOR ON FILM.film_Id = FILM_ACTOR.film_id LEFT JOIN FILM_LANGUAGE ON FILM_LANGUAGE.film_id = FILM.film_Id WHERE FILM.film_Id  =?" ;
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						pst.setInt(1, filmid);
						int count=pst.executeUpdate();
						if(count>0)
							flag=true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(sql);
					
					return flag;

		}
		

	@Override
	public List<Film> getAllFilms() {
		List<Film> filmList=new ArrayList<>();
		Connection con=getConnection();
		String sql;
		sql="select * from FILM";
		try {
			PreparedStatement pst;
			pst=con.prepareStatement(sql);
			ResultSet rs;
			rs=pst.executeQuery();
			while(rs.next())
			{
				Film film=new Film();
				film.setFilm_id(rs.getInt(1));
				film.setTitle(rs.getString(2));
			    film.setDescription(rs.getString(3));
			    film.setReleaseYear(rs.getDate(4));

			    String subsql;
				subsql="select language_name from languages where language_Id="+rs.getInt(5);
				PreparedStatement pst1=con.prepareStatement(subsql);
				ResultSet rs3=pst1.executeQuery();
				Language lang=new Language();
				if(rs3.next())
				{
					lang.setLanguage_id(rs.getInt(5));
					lang.setLanguage_name(rs3.getString(1));
				}
				film.setOriginalLanguage(lang);
				
				subsql="select language_id from film_language where film_id="+rs.getInt(1);
				PreparedStatement pst4=con.prepareStatement(subsql);
			    rs3=pst4.executeQuery();
			    List<Language> languages=new ArrayList<>();
				while(rs3.next())
				{
					String subsql1="select language_name from LANGUAGES where language_Id="+rs3.getInt(1);
					PreparedStatement pst2=con.prepareStatement(subsql1);
					ResultSet rs1=pst2.executeQuery();
					while(rs1.next()){
						Language langs=new Language();
						langs.setLanguage_id(rs3.getInt(1));
						langs.setLanguage_name(rs1.getString(1));
						languages.add(langs);
						
					}
				}
				film.setLanguages(languages);
			    
			    film.setRentalDuration(rs.getDate(6));
			    film.setLength(rs.getInt(7));
			    film.setReplacementCost(rs.getDouble(8));
			    film.setRatings(rs.getInt(9));
			    film.setSpecialFeatures(rs.getString(10));
			   String subsql1="select category_name from CATEGORY where category_Id="+rs.getInt(11);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs5=pst2.executeQuery();
				Category category=new Category();
				if(rs5.next())
				{
					category.setCategory_id(rs.getInt(11));
					category.setCategory_name(rs5.getString(1));
				}
				film.setCategory(category);
				
			    subsql="select actor_id from film_actor where film_id="+rs.getInt(1);
			   PreparedStatement pst3=con.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
			    Set<Actor> actors=new HashSet<>();
				while(rs3.next())
				{
					String subsql2="select first_name,last_name from actor where actor_Id="+rs3.getInt(1);
					PreparedStatement pst5=con.prepareStatement(subsql2);
					ResultSet rs1=pst5.executeQuery();
					while(rs1.next()){
						Actor actr=new Actor();
						actr.setActor_firstName(rs1.getString(1));
						
						actr.setActor_lastName(rs1.getString(2));
						actr.setActor_id(rs3.getInt(1));
						actors.add(actr);
						
					}
				}
				film.setActors(actors);
				System.out.println(film);
				filmList.add(film);
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 return filmList;
	}

	@Override
	public List<Film> searchFilm(Film film) {
		//create db connection
		Connection con=getConnection();
		List<Film> filmList=new ArrayList<>();
String sql="select * from FILM where ";
	
	int count=0;
		
if(film!=null){
			
	        //Filmid
	        if(film.getFilm_id()!=0)
	        {
	        	sql+="film_Id="+film.getFilm_id();
	        	count++;
	        }
			//Title
			if(film.getTitle()!=null && film.getTitle().length()!=0){
				
				if(count==1)
				{
				sql+=" and title='"+film.getTitle()+"'";
				count++;
				}
				else
					sql+="title='"+film.getTitle()+"'";
				
			}
			
			//Language
			if(film.getOriginalLanguage()!=null)
			{
				Language lang=film.getOriginalLanguage();
				
				if(count==1||count==2)
				{
					sql+=" and( film_Id In(Select film_id from FILM_LANGUAGE where language_id="+lang.getLanguage_id()+") or film_Id In( Select film_Id from FILM where originalLanguage="+lang.getLanguage_id()+"))";
				count++;
				}
				else
				{
					sql+=" (film_Id In(Select film_id from FILM_LANGUAGE where language_id="+lang.getLanguage_id()+") or film_Id In( Select film_Id from FILM where originalLanguage="+lang.getLanguage_id()+"))";
				}
			}
			
			//Actor
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
				Set<Actor> act=film.getActors();
				for(Actor a:act)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and film_Id IN (select film_id from FILM_ACTOR where actor_id="+actor.getActor_id()+")";
					count++;
				}
				else
				{
					sql+="film_Id IN (select film_id from FILM_ACTOR where actor_id="+actor.getActor_id()+")";
				}
				
			}
			
		//release year
			if(film.getReleaseYear()!=null)
			{
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
					count++;
				}
				else
				{
					sql+="releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
			}
			
			//ratings
			if(film.getRatings()!=0)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" and ratings="+film.getRatings();
					count++;
				}
				else
				{
					sql+="ratings="+film.getRatings();
				}
			}
}
System.out.println(sql);
try {
	PreparedStatement pst=getConnection().prepareStatement(sql);
	
	ResultSet rs=pst.executeQuery();
	while(rs.next()){
		
		Film film1=new Film();
		film1.setFilm_id(rs.getInt(1));
		film1.setTitle(rs.getString(2));
		film1.setDescription(rs.getString(3));
		 film1.setReleaseYear(rs.getDate(4));

		    String subsql;
			subsql="select language_name from languages where language_Id="+rs.getInt(5);
			PreparedStatement pst1=con.prepareStatement(subsql);
			ResultSet rs3=pst1.executeQuery();
			Language lang=new Language();
			if(rs3.next())
			{
				lang.setLanguage_id(rs.getInt(5));
				lang.setLanguage_name(rs3.getString(1));
			}
			film1.setOriginalLanguage(lang);
			
			subsql="select language_id from film_language where film_id="+rs.getInt(1);
			PreparedStatement pst4=con.prepareStatement(subsql);
		    rs3=pst4.executeQuery();
		    List<Language> languages=new ArrayList<>();
			while(rs3.next())
			{
				String subsql1="select language_name from LANGUAGES where language_Id="+rs3.getInt(1);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs1=pst2.executeQuery();
				while(rs1.next()){
					Language langs=new Language();
					langs.setLanguage_id(rs3.getInt(1));
					langs.setLanguage_name(rs1.getString(1));
					languages.add(langs);
					
				}
			}
			film1.setLanguages(languages);
		    
		    film1.setRentalDuration(rs.getDate(6));
		    film1.setLength(rs.getInt(7));
		    film1.setReplacementCost(rs.getDouble(8));
		    film1.setRatings(rs.getInt(9));
		    film1.setSpecialFeatures(rs.getString(10));
		   String subsql1="select category_name from CATEGORY where category_Id="+rs.getInt(11);
			PreparedStatement pst2=con.prepareStatement(subsql1);
			ResultSet rs5=pst2.executeQuery();
			Category category=new Category();
			if(rs5.next())
			{
				category.setCategory_id(rs.getInt(11));
				category.setCategory_name(rs5.getString(1));
			}
			film1.setCategory(category);
			
		    subsql="select actor_id from film_actor where film_id="+rs.getInt(1);
		   PreparedStatement pst3=con.prepareStatement(subsql);
		    rs3=pst3.executeQuery();
		    Set<Actor> actors=new HashSet<>();
			while(rs3.next())
			{
				String subsql2="select first_name,last_name from actor where actor_Id="+rs3.getInt(1);
				PreparedStatement pst5=con.prepareStatement(subsql2);
				ResultSet rs1=pst5.executeQuery();
				while(rs1.next()){
					Actor actr=new Actor();
					actr.setActor_firstName(rs1.getString(1));
					
					actr.setActor_lastName(rs1.getString(2));
					actr.setActor_id(rs3.getInt(1));
					actors.add(actr);
					
				}
			}
			film1.setActors(actors);
		
		
		filmList.add(film1);
	}
	
	
	
	
	
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}	System.out.println(filmList);
		return filmList;
	}

	@Override
	public void updateFilm(Film film) {
		Connection con=getConnection();
		String sql="UPDATE FILM SET title='"+film.getTitle()+"', "+"description='"+film.getDescription()+"', "+
		"releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"', "+"originalLanguage='"+film.getOriginalLanguage().getLanguage_id()+"', "+
		"rentalDuration='"+new java.sql.Date(film.getRentalDuration().getTime())+"', "+"len="+film.getLength()+", replacementCost="+film.getReplacementCost()+
		", ratings="+film.getRatings()+", specialFeatures='"+film.getSpecialFeatures()+"', "+"category="+film.getCategory().getCategory_id()+" WHERE film_Id="+film.getFilm_id()+";";
		System.out.println(sql);
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			int count=pst.executeUpdate();
			
			//insertion to third party tables
			int filmId=film.getFilm_id();
			
					
			sql="delete from film_actor where film_id="+filmId;
			PreparedStatement stmt = con.prepareStatement(sql);
			int count1= stmt.executeUpdate();
			
			sql="insert into film_actor(film_id,actor_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the actors in the film
			Set<Actor> actors = film.getActors();			
			for(Actor act: actors){
				pst.setInt(1, filmId );
				pst.setInt(2, act.getActor_id());
				
				count=pst.executeUpdate();
			}
			
			sql="delete from film_language where film_id="+filmId;
			 stmt = con.prepareStatement(sql);
			 count1= stmt.executeUpdate();
							
			sql="insert into film_language(film_id,language_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the other languages
			List<Language> languages = film.getLanguages();				
			for(Language lang: languages){
				pst.setInt(1, filmId );
				pst.setInt(2, lang.getLanguage_id());
				
				count=pst.executeUpdate();
			}

		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	

	
	
	

}
