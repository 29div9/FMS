package org.capgemini.service;

import java.util.List;

import org.capgemini.dao.IActorDAOImplementation;
import org.capgemini.dao.IActorDao;
import org.capgemini.domain.Actor;

public class IActorServiceImplementation implements IActorService{

	private IActorDao actorDao=new IActorDAOImplementation();
	@Override
	public List<Actor> getActors() {
		IActorDAOImplementation actorDao=new IActorDAOImplementation();
		return actorDao.getActors();
	}

	@Override
	public void addActor(Actor actor) {
		
		actorDao.addActor(actor);
	}

	@Override
	public List<Actor> getAllActors() {
		return actorDao.getAllActors();
	}

	@Override
	public boolean deleteActor(int actorid) {
		return actorDao.deleteActor(actorid);	}

}
