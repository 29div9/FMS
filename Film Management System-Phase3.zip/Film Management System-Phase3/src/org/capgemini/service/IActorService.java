package org.capgemini.service;

import java.util.List;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;

public interface IActorService {
	public List<Actor> getActors();
	public void addActor(Actor actor);
	public List<Actor> getAllActors();
	public boolean deleteActor(int actorid);
}
