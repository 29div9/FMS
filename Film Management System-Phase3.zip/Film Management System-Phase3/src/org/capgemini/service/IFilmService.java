package org.capgemini.service;

import java.util.List;
import java.util.Map;

import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;

public interface IFilmService {
	public List<Language> getLanguage();
	public List<Category> getCategory();
	public List<Film> getAllFilms();
	public int addFilm(Film film);
	public List<Film> searchFilm(Film film);
	public boolean deleteFilm(int filmid);
	public void updateFilm(Film film);
    
}
