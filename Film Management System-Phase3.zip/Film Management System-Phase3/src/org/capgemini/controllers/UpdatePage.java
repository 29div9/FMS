package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class UpdatePage
 */
public class UpdatePage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Film film1=new Film();
		//retrieving the existing film object
		film1=(Film)request.getAttribute("obj");
		IFilmService film_service=new IFilmServiceImplementation ();
		List<Language> languages=film_service.getLanguage();
		IActorService actor_service=new IActorServiceImplementation();
		List<Actor> actors=actor_service.getActors();
		List<Category> category=film_service.getCategory();
		SimpleDateFormat df=new SimpleDateFormat("dd-MMMM-yyyy");
		
		//html form for updating operation
		out.println("<html>");
		out.println("<head><title>Update Film</title>");
		out.println("<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
		+" <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
		+" <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
		);
out.println("<script>"
			+"$(function() {"
			+"$( '#datepicker-13' ).datepicker({ maxDate: '0',dateFormat:'dd-MM-yy'}).val();"
			+"$( '#datepicker-13' ).datepicker('show');"
			+"});"
			+"</script>"
			+"<script>"
			+"$(function() {"
			+" $('#datepicker-14').datepicker({dateFormat: 'dd-MM-yy'});"
			+"$( '#datepicker-14' ).datepicker('show');"
			+" });"
			+"</script>");
out.println("</script>");
out.println("<script type='text/javascript' src='script/validate.js'></script>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form id='updateForm'  name='updateForm' method='get' action='Update'>");
		out.println("<table>"
				   +"<tr>"
				   +"<td>Film Id:</td>"
				   +"<td><input type='text' name='id' value='"+film1.getFilm_id()+"' readonly/>"
				   +"</td></tr>"
				   +"<td>Film Title:</td>"
				   +"<td><input type='text' name='title' onmouseout='return  istitlevalidate()' value='"+film1.getTitle()+"'/>"
				   +"<div id='titleErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Film Description</td>"
				   +"<td><textarea name='description'  onmouseout='return isdescriptionvalidate()'>"+film1.getDescription()+"</textarea>"
				   +"<div id='descriptionErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Release Date</td>"
				   +"<td><input type='text' id='datepicker-13' name='release_date' value='"+df.format(film1.getReleaseYear())+"'></td>"
				   +"</tr>"
				  );
		out.println("<tr>"
				   +"<td>Original Language</td>");
				   out.println("<td><select name='lang' >");
				   for(Language lang:languages){
					
					   if(film1.getOriginalLanguage().getLanguage_id()==lang.getLanguage_id())
						{
						   out.println("<option value='"+ lang.getLanguage_id()+"' selected>"
						
								+lang.getLanguage_name()+ "</option>");
						}
					   else
					   {
						   out.println("<option value='"+ lang.getLanguage_id()+"'>"
									
								+lang.getLanguage_name()+ "</option>"); 
					   }
						
				   }
				   
				 out.println("</select></td></tr>");
				 out.println("<tr>"
						   +"<td>Languages</td>");
				
						   out.println("<td><select name='lang1' multiple>");
						   for(Language l:languages) {
							   int flag=0;
							   for(Language lang:film1.getLanguages())
							   {  
							   if(lang.getLanguage_id()==l.getLanguage_id())
							   {
								   out.println("<option value='"+ l.getLanguage_id()+"' selected>"
							   
										+l.getLanguage_name()+ "</option>");
								  flag=1;
								  break;
								  
							   }
							   }
							   
							  if(flag!=1)
							   
								   out.println("<option value='"+ l.getLanguage_id()+"'>"
											
										+l.getLanguage_name()+ "</option>"); 
							   
							 
							   
						   }
						   
						 out.println("</select></td></tr>");
						 out.println("<tr>"
								   +"<td>Rental Duration:</td>"
								   +"<td><input type='text' id='datepicker-14' name='rental_duration' value='"+df.format(film1.getRentalDuration())+"'>"
								   +"<div id='rentalErr' class='errMsg'></div></td>"
								   +"</tr><tr>"
								   +"<td>Length:</td>"
								   +"<td><input type='text' name='length' onmouseout='return isValidLength()' value='"+film1.getLength()+"'/>"
								   +"<div id='lengthErr' class='errMsg'></div>"
								   +"</td></tr>"
								   +"<tr>"
								   +"<td>Replacement Cost:</td>"
								   +"<td><input type='text' name='replacement_cost' onmouseout='return isreplacementvalidate()' value='"+film1.getReplacementCost()+"'/>"
								   +"<div id='replacement_costErr' class='errMsg'></div>"
								   +"</td></tr><tr>"
								   +"<td>Ratings:</td>"
								   +"<td><input type='number' name='ratings' min='1' max='5' step='1' value='"+film1.getRatings()+"'>"
								   +"<div id='ratingsErr' class='errMsg'></div>"
								   +"</td></tr><tr>"
								   +"<td>Special Feature:</td>"
								   +"<td><textarea name='special_feature' onmouseout='return isspecialvalidate()'>"+film1.getDescription()+"</textarea>"
								   +"<div id='special_featureErr' class='errMsg'></div>"
								   +"</td></tr>"
								);
						
						 out.println("<tr>"
								   +"<td>Actors</td>");
								   out.println("<td><select name='actor' multiple>");
								   for(Actor a:actors)   {
									   int flag=0;
									   for(Actor act:film1.getActors())
									   {
										   
									   if(act.getActor_id()==a.getActor_id())
									   {
										out.println("<option value='"+ a.getActor_id()+"' selected>"
												+a.getActor_firstName()+" "+a.getActor_lastName()+ "</option>");
										flag=1;
										break;
									   }
									   }
									  if(flag!=1)
									   {
										   out.println("<option value='"+ a.getActor_id()+"'>"
													+a.getActor_firstName()+" "+a.getActor_lastName()+ "</option>");
									   }
										
										
								  
								   }
								   
								 out.println("</select></td></tr>");
								 
								 out.println("<tr>"
										   +"<td>Category:</td>");
										   out.println("<td><select name='category' >");
										   for(Category cat:category){
											   if(film1.getCategory().getCategory_id()==cat.getCategory_id())
											   {
												out.println("<option value='"+ cat.getCategory_id()+"' selected>"
														+cat.getCategory_name()+ "</option>");
											   }
											   else
											   {
												   out.println("<option value='"+ cat.getCategory_id()+"'>"
															+cat.getCategory_name()+ "</option>");
											   }
												
										   }
										   
										 out.println("</select></td></tr>");
								 
						out.println("<tr>"
								+"<td></td>"
								+"<td><input type='submit' value='Update'>"
								+"<input type='reset' value='Clear'>"
								 +"</td>"
							+"</tr>");
		  out.println("</table>");
	      out.println("</form>");
		  out.println("</body>");
		  out.println("</html>");
		
	}

}
