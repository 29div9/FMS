package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class ListAll
 */
public class ListAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService film_service=new IFilmServiceImplementation ();
		List<Film> films=film_service.getAllFilms();
		
		List<Language> languages=film_service.getLanguage();
	PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head></head>"
				+ "<body>"
				+"<h1 align='center'>Film Details</h1>"
				+ "<div style='margin-left:500px;'><br>"
				+"</br> </div>"
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Original Language</th>"
				+ "<th>Other Languages</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Feature</th>"
				+ "<th colspan='2'>Actors</th>"
				+ "<th>Category</th>"
				+ "</tr>");
		Set<Actor> actors=new HashSet<>();
		List<Language> lang=new ArrayList<>();
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_id()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguage_name()+"</td>");
				
				lang=film.getLanguages();
				out.println("<td>");
				for(Language lan:lang)
				{
					out.println(lan.getLanguage_name());
				}
				out.println("</td>");
			//	out.println("<td>"+film.getLanguages()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecialFeatures()+"</td>");
			
				actors=film.getActors();
				out.println("<td colspan='2'>");
				for(Actor act:actors){
					out.println( act.getActor_firstName());
					out.println(act.getActor_lastName());
				
				}
				out.println("</td>");
				out.println("<td>"+film.getCategory().getCategory_name()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
		
		
	}

}
