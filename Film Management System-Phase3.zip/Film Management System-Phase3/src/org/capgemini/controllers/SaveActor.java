package org.capgemini.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;

/**
 * Servlet implementation class SaveActor
 */
public class SaveActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Actor actor=new Actor();
		actor.setActor_firstName(request.getParameter("first_name"));
		actor.setActor_lastName(request.getParameter("last_name"));
		request.getRequestDispatcher("demo").forward(request, response);
	}

}
