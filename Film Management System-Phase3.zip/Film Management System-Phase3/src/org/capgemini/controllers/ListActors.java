package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;

/**
 * Servlet implementation class ListActors
 */
public class ListActors extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actor_service=new IActorServiceImplementation();
		List<Actor> actors=actor_service.getAllActors();
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head></head>"
				+ "<body>"
				+"<h1 align='center'>Actor Details</h1>"
				+ "<div style='margin-left:500px;'><br>"
				+"</br> </div>"
				+ "<table border='1' align='center'>"
				+ "<tr>"
				+ "<th>Actor id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "</tr>");
		for(Actor actor:actors){
			out.println("<tr>");
			out.println("<td>"+actor.getActor_id()+"</td>");
			out.println("<td>"+actor.getActor_firstName()+"</td>");
			out.println("<td>"+actor.getActor_lastName()+"</td>");
			out.println("</tr>");
			
		
		}
		out.println("</table></body>");
		
		out.println("</html>");
		}
	}


