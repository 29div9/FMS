package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;

/**
 * Servlet implementation class DeleteActorPage
 */
public class DeleteActorPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actor_service=new IActorServiceImplementation();
		List<Actor> actor_list=actor_service.getAllActors();
		PrintWriter out=response.getWriter();	
		if(actor_list.isEmpty())
		{
			out.println("<html>");
			out.println("<head></head>"
					+ "<body>"
					+"<h1 align='center'>Actor Details</h1>"
					+ "<div style='margin-left:500px;'>"
					+"</br> </div>");
			out.println("<h3 align='center'>No actor to show!!</h3>");
			out.println("</html>");
		}
		else
		{
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				
				
				+ "<table border=1>"
				+ "<tr>"
				+ "<th>Actor Id </th>"
				+ "<th> First Name </th>"
				+ "<th> Last Name </th>"
				+ "</tr>");
		for(Actor actor:actor_list){
			out.println("<tr>");
			out.println("<td>"+actor.getActor_id()+"</td>");
			out.println("<td>"+actor.getActor_firstName()+"</td>");
			out.println("<td>"+actor.getActor_lastName()+"</td>");
			out.println("<td><a href='DeleteActorServlet?actorid="+actor.getActor_id()+"'>Delete</a></td>");
			out.println("</tr>");
		}
		out.println("</table></body>");
		
		out.println("</html>");
		}
	}

}
