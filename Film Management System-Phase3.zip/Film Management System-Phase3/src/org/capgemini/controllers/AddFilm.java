package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Language;
import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class AddFilm
 */
public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IFilmService film_service=new IFilmServiceImplementation ();
		IActorService actor_service=new IActorServiceImplementation();
		List<Language> languages=film_service.getLanguage();
		List<Actor> actors=actor_service.getActors();
		List<Category> category=film_service.getCategory();
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Add Film</title>"
				+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+" <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+" <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				);
		out.println("<script>"
  				+"$(function() {"
  				+"$( '#datepicker-13' ).datepicker({ maxDate: '0',dateFormat:'dd-MM-yy'}).val();"
  				+"$( '#datepicker-13' ).datepicker('show');"
  				+"});"
  				+"</script>"
  				+"<script>"
  				+"$(function() {"
  				+" $('#datepicker-14').datepicker({dateFormat: 'dd-MM-yy'});"
  				+"$( '#datepicker-14' ).datepicker('show');"
  				+" });"
  				+"</script>");
		out.println("</script>");
		out.println("<script type='text/javascript' src='script/validate.js'></script>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form id='filmForm'  name='myForm' action='SaveFilm' >");
		out.println("<table>"
				   +"<th>Create New Film</th>"
				   +"<tr><td></td><td></td>"
				   +"</tr>"
				   +"<tr><td></td>"
				   +"</tr>"
				   +"<tr>"
				   +"<td>Film Title</td>"
				   +"<td><input type='text' name='title' onmouseout='return  istitlevalidate()'/>"
				   +"<div id='titleErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Film Description</td>"
				   +"<td><textarea name='description'  onmouseout='return isdescriptionvalidate()'></textarea>"
				   +"<div id='descriptionErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Release Date</td>"
				   +"<td><input type='text' id='datepicker-13' name='release_date' placeholder='DD/MMM/YYYY'></td>"
				   +"</tr>");
				   out.println("<tr>"
				   +"<td>Original Language</td>");
				   out.println("<td><select name='lang' >");
				   for(Language lang:languages){
						out.println("<option value='"+ lang.getLanguage_id()+"'>"
								+lang.getLanguage_name()+ "</option>");
						
						
				   }
				   
				 out.println("</select></td></tr>");
				   
				 out.println("<tr>"
						   +"<td>Languages</td>");
						   out.println("<td><select name='lang1' multiple>");
						   for(Language lang:languages){
								out.println("<option value='"+ lang.getLanguage_id()+"'>"
										+lang.getLanguage_name()+ "</option>");
								
								
						   }
						   
						 out.println("</select></td></tr>");
						   
		out.println("<tr>"
				   +"<td>Rental Duration</td>"
				   +"<td><input type='text' id='datepicker-14' name='rental_duration'>"
				   +"<div id='rentalErr' class='errMsg'></div></td>"
				   +"</tr><tr>"
				   +"<td>Length</td>"
				   +"<td><input type='text' name='length' onmouseout='return isValidLength()'/>"
				   +"<div id='lengthErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Replacement Cost</td>"
				   +"<td><input type='text' name='replacement_cost' onmouseout='return isreplacementvalidate()'/>"
				   +"<div id='replacement_costErr' class='errMsg'></div>"
				   +"</td></tr><tr>"
				   +"<td>Ratings</td>"
				   +"<td><input type='number' name='ratings' min='1' max='5' step='1' value='1'>"
				   +"<div id='ratingsErr' class='errMsg'></div>"
				   +"</td></tr><tr>"
				   +"<td>Special Feature</td>"
				   +"<td><textarea name='special_feature' onmouseout='return isspecialvalidate()'></textarea>"
				   +"<div id='special_featureErr' class='errMsg'></div>"
				   +"</td></tr>"
				);
		
		 out.println("<tr>"
				   +"<td>Actors</td>");
				   out.println("<td><select name='actor' multiple>");
				   for(Actor act:actors){
						out.println("<option value='"+ act.getActor_id()+"'>"
								+act.getActor_firstName()+" "+act.getActor_lastName()+ "</option>");
						
						
				   }
				   
				 out.println("</select></td></tr>");
				 
				 out.println("<tr>"
						   +"<td>Category</td>");
						   out.println("<td><select name='category' >");
						   for(Category cat:category){
								out.println("<option value='"+ cat.getCategory_id()+"'>"
										+cat.getCategory_name()+ "</option>");
								
								
						   }
						   
						 out.println("</select></td></tr>");
				 
		out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
        out.println("</table>");
        out.println("</form");
		out.println("</body>");
		out.println("</html>");
	}

}

