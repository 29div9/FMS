package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class DeletePage
 */
public class DeletePage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService film_service=new IFilmServiceImplementation ();
		List<Film> films=film_service.getAllFilms();
		PrintWriter out=response.getWriter();	
		if(films.isEmpty())
		{
			out.println("<html>");
			out.println("<head></head>"
					+ "<body>"
					+"<h1 align='center'>Film Details</h1>"
					+ "<div style='margin-left:500px;'>"
					+"</br> </div>");
			out.println("<h3 align='center'>No films to show!!</h3>");
			out.println("</html>");
		}
		else
		{
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				
				
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Name </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Category	</th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_id()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguage_id()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				List<Language>langs=new ArrayList<>();
				langs=film.getLanguages();
				out.println("<td>");
				for(Language lang:langs)
					out.println(lang.getLanguage_name());
				out.println("</td>");
				Set<Actor> actors =new HashSet<>();
				actors=film.getActors();
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getActor_firstName()+" "+act.getActor_lastName());
				out.println("</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_name()+"</td>");
				out.println("<td><a href='DeleteServlet?filmid="+film.getFilm_id()+"'>Delete</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
	}
	}

}
