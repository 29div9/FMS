package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;

/**
 * Servlet implementation class DeleteActorServlet
 */
public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String actorid=request.getParameter("actorid");
		System.out.println(actorid);
		IActorService actor_service=new IActorServiceImplementation();
		boolean flag=actor_service.deleteActor(Integer.parseInt(actorid));
		if(flag==true)
		{
			request.getRequestDispatcher("DeleteActorPage").forward(request, response);
		}
	}

}
