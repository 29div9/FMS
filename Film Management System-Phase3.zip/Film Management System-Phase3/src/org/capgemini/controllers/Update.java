package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class Update
 */
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		Film film=new Film();
		IFilmService film_service=new IFilmServiceImplementation ();
		List<Language> selected_languages=new ArrayList<>();
		Set<Actor> selected_actors=new HashSet<>();
		
		//retrieving fields of update form and setting them to film obj
		film.setFilm_id(Integer.parseInt(request.getParameter("id")));
		film.setTitle(request.getParameter("title"));
		film.setDescription(request.getParameter("description"));
		
		String release=request.getParameter("release_date");
		System.out.println(release);
		Date releaseDate=new Date(release);
		film.setReleaseYear(releaseDate);
		Integer langId=Integer.parseInt(request.getParameter("lang"));
		Language lang=new Language();
		lang.setLanguage_id(langId);
		film.setOriginalLanguage(lang);
		String[] olanguage=request.getParameterValues("lang1");
		for(String ol:olanguage)
		{
			Language language=new Language();
			language.setLanguage_id(Integer.parseInt(ol));
			selected_languages.add(language);
		}
		film.setLanguages(selected_languages);
		String rental=request.getParameter("rental_duration");
		Date rentalDate=new Date(rental);
		film.setRentalDuration(rentalDate);
		film.setLength(Integer.parseInt(request.getParameter("length")));
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacement_cost")));
		film.setRatings(Integer.parseInt(request.getParameter("ratings")));
		film.setSpecialFeatures(request.getParameter("special_feature"));
		String[] actors1=request.getParameterValues("actor");
		for(String act1:actors1)
		{
			Actor actor=new Actor();
			actor.setActor_id(Integer.parseInt(act1));
			selected_actors.add(actor);
		}
		film.setActors(selected_actors);
		Integer category=Integer.parseInt(request.getParameter("category"));
		Category cat=new Category();
		cat.setCategory_id(category);
		film.setCategory(cat);
		film_service.updateFilm(film);
		request.getRequestDispatcher("demo").forward(request, response);
	}

}
