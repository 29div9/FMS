package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Film film=new Film();
		Set<Actor> selected_actors=new HashSet<>();
		IFilmService film_service=new IFilmServiceImplementation ();
	
		try
		{
			if(request.getParameter("byId")!="")
		film.setFilm_id(Integer.parseInt(request.getParameter("byId")));
		}catch(NumberFormatException e)
		{
			e.printStackTrace();
		}
		if(request.getParameter("byTitle")!="")
		film.setTitle(request.getParameter("byTitle"));
		if(Integer.parseInt(request.getParameter("ByLanguage"))>0)
		{
		Language lang=new Language();
		Integer langId=Integer.parseInt(request.getParameter("ByLanguage"));
		lang.setLanguage_id(langId);
		film.setOriginalLanguage(lang);
		}
		if(Integer.parseInt(request.getParameter("byActor"))>0)
		{
		String[] actors1=request.getParameterValues("byActor");
		for(String act1:actors1)
		{
			Actor actor=new Actor();
			actor.setActor_id(Integer.parseInt(act1));
			selected_actors.add(actor);
		}
		film.setActors(selected_actors);
		}
		if(request.getParameter("releasedate")!="")
		{	
			Date release=new Date(request.getParameter("releasedate"));
			film.setReleaseYear(release);	
		}
		if(request.getParameter("byRatings")!="")
		{
			film.setRatings(Integer.parseInt(request.getParameter("byRatings")));
		}
		System.out.println(film);
		List<Film> films=film_service.searchFilm(film);
		if(films.isEmpty())
		{
			out.println("<html>");
			out.println("<head></head>"
					+ "<body>"
					+"<h1 align='center'>Film Details</h1>"
					+ "<div style='margin-left:500px;'>"
					+"</br> </div>");
			out.println("<h3 align='center'>Film Not Found!!</h3>");
			out.println("</html>");
		}
		else
		{
		out.println("<html>");
		out.println("<head></head>"
				+ "<body>"
				+"<h1 align='center'>Film Details</h1>"
				+ "<div style='margin-left:500px;'><br>"
				+"</br> </div>"
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Original Language</th>"
				+ "<th>Other Languages</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Feature</th>"
				+ "<th colspan='2'>Actors</th>"
				+ "<th>Category</th>"
				+ "<th colspan='2'>Actions</th>"
				+ "</tr>");
		
		Set<Actor> actors=new HashSet<>();
		List<Language> language=new ArrayList<>();
		for(Film f:films){
			out.println("<tr>");
			out.println("<td>"+f.getFilm_id()+"</td>");
			out.println("<td>"+f.getTitle()+"</td>");
			out.println("<td>"+f.getDescription()+"</td>");
			out.println("<td>"+f.getReleaseYear()+"</td>");
			out.println("<td>"+f.getRentalDuration()+"</td>");
			out.println("<td>"+f.getOriginalLanguage().getLanguage_name()+"</td>");
			language=f.getLanguages();
			out.println("<td>");
			for(Language lan:language)
			{
				out.println(lan.getLanguage_name());
			}
			out.println("</td>");
			out.println("<td>"+f.getLength()+"</td>");
			out.println("<td>"+f.getReplacementCost()+"</td>");
			out.println("<td>"+f.getRatings()+"</td>");
			out.println("<td>"+f.getSpecialFeatures()+"</td>");
		
			actors=f.getActors();
			out.println("<td colspan='2'>");
			for(Actor act:actors){
				out.println( act.getActor_firstName());
				out.println(act.getActor_lastName());
			
			}
			out.println("</td>");
			out.println("<td>"+f.getCategory().getCategory_name()+"</td>");
			out.println("<td><a href='DeleteServlet?filmid="+f.getFilm_id()+"'>Delete</a></td>");
			out.println("<td><a href='UpdateServlet?filmid="+f.getFilm_id()+"'>Update</a></td>");
			out.println("</tr>");
		}
		out.println("</table></body>");
		
		out.println("</html>");
		}
	}

}
