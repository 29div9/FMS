package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Language;
import org.capgemini.service.IActorService;
import org.capgemini.service.IActorServiceImplementation;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class SearchFilm
 */
public class SearchPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out=response.getWriter();
	IFilmService film_service=new IFilmServiceImplementation ();
	IActorService actor_service=new IActorServiceImplementation();
	List<Language> languages=film_service.getLanguage();
	List<Actor> actors=actor_service.getActors();
	out.println("<html>");
	out.println("<head><title>Search Film</title>");
	out.println("<script type='text/javascript' src=''></script>"
			+ "<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
			+"<meta charset='ISO-8859-1'>"
	+ "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
	 +"     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
	    +"  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
	      +"<!-- Javascript -->"
	  +"    <script>"
	  +"       $(function() {"
	     +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
	        +"    $( '#datepicker1' ).datepicker('show');"
	         +"});"
	         + "</script>");
	out.println("</head>");
	out.println("<body>");
	out.println("<form name='searchForm' method='post' action='SearchServlet'>");
	out.println("<div>");
	out.println("By Id:<input type='textbox' name='byId'/> ");
	out.println("<br>");
	out.println("<br>");
	out.println("By Title:<input type='textbox' name='byTitle'/> ");
	out.println("<br>");
	out.println("<br>");
	out.println("By Language:<select name='ByLanguage'> "
			+ "<option value='0'>--Select--</option>");
	  for(Language lang:languages){
			out.println("<option value='"+ lang.getLanguage_id()+"'>"
					+lang.getLanguage_name()+ "</option>");	
	   }
	out.println("</select>");
	out.println("<br>");
	out.println("<br>");
	out.println("<br>");
	out.println("By Actor:<select name='byActor'>"
			+ "<option value='0'>--Select--</option>");
	for(Actor act: actors)
	{
		out.println("<option value='"+act.getActor_id()+"'>"
				+act.getActor_firstName()+" "+act.getActor_lastName()
				+"</option>");
		
	}
	out.println("</select>");
	out.println("<br>");
	out.println("<br>");
	out.println("Release Date:<input type='text' id='datepicker1' name='releasedate' size='20'>");
	out.println("<br>");
	out.println("<br>");
	out.println("By Ratings:<input type='number' name='byRatings' min='0' max='5' step='1' value='0'>");
	out.println("</div>");
	out.println("<br>");
	out.println("<br>");
	out.println("<input type='submit' value='search' name='search'>");
	out.println("</form>");
	out.println("</body>");
	out.println("</html>");
	}

}
