package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddActor
 */
public class AddActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Add Actor</title>");
		out.println("<script type='text/javascript' src='script/validate.js'></script>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form id='actorForm'  name='myForm' action='SaveActor' >");
		out.println("<table>"
				   +"<th>Add Actor</th>"
				   +"<tr><td></td><td></td>"
				   +"</tr>"
				   +"<tr><td></td>"
				   +"</tr>"
				   +"<tr>"
				   +"<td>First Name:</td>"
				   +"<td><input type='text' name='first_name' onmouseout='return  isNameValidate()'/>"
				   +"<div id='nameErr' class='errMsg'></div>"
				   +"</td></tr>"
				   +"<tr>"
				   +"<td>Last Name:</td>"
				   +"<td><input type='text' name='last_name' />"
				 //  +"<div id='nameErr' class='errMsg'></div>"
				   +"</td></tr>");
		out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
		 out.println("</table>");
	        out.println("</form");
			out.println("</body>");
			out.println("</html>");
	}

}
