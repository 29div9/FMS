package org.capgemini.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Film;
import org.capgemini.service.IFilmService;
import org.capgemini.service.IFilmServiceImplementation;

/**
 * Servlet implementation class UpdateServlet
 */
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String filmid=request.getParameter("filmid");
		Film film=new Film();
		film.setFilm_id(Integer.parseInt(filmid));
		IFilmService film_service=new IFilmServiceImplementation ();
		List<Film> updateFilm=film_service.searchFilm(film);
		for(Film f:updateFilm)
		{
			film=f;
		}
		request.setAttribute("obj", film);
		if(!updateFilm.isEmpty())
		{
			request.getRequestDispatcher("UpdatePage").forward(request, response);
		}
	}

}
