package org.capgemini.testing;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capgemini.dao.IActorDAOImplementation;
import org.capgemini.dao.IFilmImplementation;
import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.junit.Assert;
import org.junit.Test;

public class TestMethods {

	IFilmImplementation film_dao=new IFilmImplementation();
	IActorDAOImplementation actor_dao=new IActorDAOImplementation();
	List<Language> testLanguageList=new ArrayList<>();
	List<Actor> testActorList=new ArrayList<>();
	List<Category> testCategoryList=new ArrayList<>();
	List<Film> testFilmList=new ArrayList<>();
	List<Film> expectedFilmList=new ArrayList<>();
	Category category=new Category();
	Set<Actor> actor_set=new HashSet<>();
	@Test
	public void testGetLanguageList() {
		
		Language language=new Language();
		testLanguageList.add(new Language(1,"English"));
		testLanguageList.add(new Language(2,"Hindi"));
		testLanguageList.add(new Language(3,"Malayalam"));
		testLanguageList.add(new Language(4,"Marathi"));
		testLanguageList.add(new Language(5,"Punjabi"));
		testLanguageList.add(new Language(6,"Chinese"));
		testLanguageList.add(new Language(7,"French"));
		Assert.assertEquals(testLanguageList, film_dao.getLanguages());
	}
	
	@Test
	public void testLanguageListIsNotNull()
	{
		assertNotNull(film_dao.getLanguages());
	}
	
	@Test
	public void testLengthOfLanguageList()
	{
		assertEquals(7, film_dao.getLanguages().size());
	}
	
	@Test
	public void testActorListIsNotNull()
	{
		assertNotNull(actor_dao.getActors());
	}
	
	@Test
	public void testGetListOfActors() {
		
		
		
		testActorList.add(new Actor(4,"Jennifer","Aniston"));
		testActorList.add(new Actor(5,"Aamir","Khan"));
		testActorList.add(new Actor(6,"Kangana","Ranaut"));
		testActorList.add(new Actor(7,"Mohan","Lal"));
		testActorList.add(new Actor(8,"Swapnil","Joshi"));
		testActorList.add(new Actor(9,"Dulquar","Salman"));
		testActorList.add(new Actor(13,"Shahrukh","Khan"));
		assertEquals(testActorList, actor_dao.getActors());
	}
	
	
	
	@Test
	public void testGetListOfCategory() {
		
		testCategoryList.add(new Category(1,"Drama"));
		testCategoryList.add(new Category(2,"Romance"));
		testCategoryList.add(new Category(3,"Sci-fi"));
		testCategoryList.add(new Category(4,"Horror"));
		testCategoryList.add(new Category(5,"Comedy"));
		testCategoryList.add(new Category(6,"Action"));
		
		assertEquals(testCategoryList, film_dao.getCategory());
	}
	
	@Test
	public void testCategoryListIsNotNull()
	{
		assertNotNull(film_dao.getCategory());
	}
	
	@Test
	public void testLengthOfCategoryList()
	{
		assertEquals(6, film_dao.getCategory().size());
	}
	
	@Test
	public void testDeleteActorReturnsBoolean()
	{
		assertTrue(actor_dao.deleteActor(4));
	}
	
	@Test
	public void testAddFilmsReturnsInteger()
	{//film_id=2, title=The Break-Up, description=Romantic comedy film, releaseYear=2006-06-02,originalLanguage=Language [language_id=1, language_name=English], languages=[Language [language_id=2, language_name=Hindi], Language [language_id=3, language_name=Malayalam]], rentalDuration=2016-05-21, length=105, replacementCost=545.0, ratings=4, specialFeatures=Excellent Direction, actors=[Actor [actor_id=4, actor_firstName=Jennifer, actor_lastName=Aniston]], category=Category [category_id=5, category_name=Comedy]
		Film film=new Film();
		film.setFilm_id(2);
		film.setTitle("The Break-Up");
		film.setDescription("Romantic comedy film");
		String releaseDate="02-jun-2006";
		Date release_date=new Date(releaseDate);
		film.setReleaseYear(release_date);
		
		Language original_language=new Language();
		original_language.setLanguage_id(1);
		original_language.setLanguage_name("English");
		film.setOriginalLanguage(original_language);
		List<Language> other_languages=new ArrayList<>();
		other_languages.add(new Language(2,"Hindi"));
		other_languages.add(new Language(3,"Malayalam"));
		film.setLanguages(other_languages);
		String rental_Duration="21-may-2016";
		Date rental_date=new Date(rental_Duration);
		film.setRentalDuration(rental_date);
		
		actor_set.add(new Actor(4,"Jennifer","Aniston"));
		film.setActors(actor_set);
		film.setCategory(new Category(5,"Comedy"));
		film.setLength(105);
		film.setReplacementCost(545.0);
		film.setRatings(4);
		film.setSpecialFeatures("Excellent Direction");
		assertEquals(1, film_dao.addFilm(film));
		
	}
	
	@Test
	public void testSearchById()
	{
		Film search_film=new Film();
		search_film.setFilm_id(2);
	
		Film film=new Film();
		film.setFilm_id(2);
		film.setTitle("The Break-Up");
		film.setDescription("Romantic comedy film");
		String releaseDate="02-jun-2006";
		Date release_date=new Date(releaseDate);
		film.setReleaseYear(release_date);
		
		Language original_language=new Language();
		original_language.setLanguage_id(1);
		original_language.setLanguage_name("English");
		film.setOriginalLanguage(original_language);
		List<Language> other_languages=new ArrayList<>();
		other_languages.add(new Language(2,"Hindi"));
		other_languages.add(new Language(3,"Malayalam"));
		film.setLanguages(other_languages);
		String rental_Duration="21-may-2016";
		Date rental_date=new Date(rental_Duration);
		film.setRentalDuration(rental_date);
		
		actor_set.add(new Actor(4,"Jennifer","Aniston"));
		film.setActors(actor_set);
		film.setCategory(new Category(5,"Comedy"));
		film.setLength(105);
		film.setReplacementCost(545.0);
		film.setRatings(4);
		film.setSpecialFeatures("Excellent Direction");
		expectedFilmList.add(film);
		assertEquals(expectedFilmList,film_dao.searchFilm(search_film));
	}
	
}
