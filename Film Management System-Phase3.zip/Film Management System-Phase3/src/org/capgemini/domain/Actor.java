package org.capgemini.domain;

public class Actor {
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actor_firstName == null) ? 0 : actor_firstName.hashCode());
		result = prime * result + actor_id;
		result = prime * result + ((actor_lastName == null) ? 0 : actor_lastName.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (actor_firstName == null) {
			if (other.actor_firstName != null)
				return false;
		} else if (!actor_firstName.equals(other.actor_firstName))
			return false;
		if (actor_id != other.actor_id)
			return false;
		if (actor_lastName == null) {
			if (other.actor_lastName != null)
				return false;
		} else if (!actor_lastName.equals(other.actor_lastName))
			return false;
		return true;
	}


	//Private fields
	private int actor_id;
	private String actor_firstName;
	private String actor_lastName;
	
	
	//Constructor with arguments
	public Actor(int actor_id, String actor_firstName, String actor_lastName) {
		super();
		this.actor_id = actor_id;
		this.actor_firstName = actor_firstName;
		this.actor_lastName = actor_lastName;
	}
	
	
	//Constructor without any argument
	public Actor() {
		super();
	}

	
	//Getters and Setters
	public int getActor_id() {
		return actor_id;
	}

	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public String getActor_firstName() {
		return actor_firstName;
	}

	public void setActor_firstName(String actor_firstName) {
		this.actor_firstName = actor_firstName;
	}

	public String getActor_lastName() {
		return actor_lastName;
	}

	public void setActor_lastName(String actor_lastName) {
		this.actor_lastName = actor_lastName;
	}

	
	@Override
	public String toString() {
		return "Actor [actor_id=" + actor_id + ", actor_firstName=" + actor_firstName + ", actor_lastName="
				+ actor_lastName + "]";
	}
	
	

}
